<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Income extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Income_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $q = urldecode($this->input->get('q', TRUE));
        $start = intval($this->input->get('start'));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . 'income/index.html?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'income/index.html?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'income/index.html';
            $config['first_url'] = base_url() . 'income/index.html';
        }

        $config['per_page'] = 10;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->Income_model->total_rows($q);
        $income = $this->Income_model->get_limit_data($config['per_page'], $start, $q);

        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            'income_data' => $income,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
        );
        $this->load->view('income/income_list', $data);
    }

    public function read($id) 
    {
        $row = $this->Income_model->get_by_id($id);
        if ($row) {
            $data = array(
		'nomor_income' => $row->nomor_income,
		'Tanggal' => $row->Tanggal,
		'Pemasukan' => $row->Pemasukan,
		'Pengeluaran' => $row->Pengeluaran,
		'Setoran' => $row->Setoran,
		'Laba_Kotor' => $row->Laba_Kotor,
	    );
            $this->load->view('income/income_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('income'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('income/create_action'),
	    'nomor_income' => set_value('nomor_income'),
	    'Tanggal' => set_value('Tanggal'),
	    'Pemasukan' => set_value('Pemasukan'),
	    'Pengeluaran' => set_value('Pengeluaran'),
	    'Setoran' => set_value('Setoran'),
	    'Laba_Kotor' => set_value('Laba_Kotor'),
	);
        $this->load->view('income/income_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'Tanggal' => $this->input->post('Tanggal',TRUE),
		'Pemasukan' => $this->input->post('Pemasukan',TRUE),
		'Pengeluaran' => $this->input->post('Pengeluaran',TRUE),
		'Setoran' => $this->input->post('Setoran',TRUE),
		'Laba_Kotor' => $this->input->post('Laba_Kotor',TRUE),
	    );

            $this->Income_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('income'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Income_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('income/update_action'),
		'nomor_income' => set_value('nomor_income', $row->nomor_income),
		'Tanggal' => set_value('Tanggal', $row->Tanggal),
		'Pemasukan' => set_value('Pemasukan', $row->Pemasukan),
		'Pengeluaran' => set_value('Pengeluaran', $row->Pengeluaran),
		'Setoran' => set_value('Setoran', $row->Setoran),
		'Laba_Kotor' => set_value('Laba_Kotor', $row->Laba_Kotor),
	    );
            $this->load->view('income/income_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('income'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('nomor_income', TRUE));
        } else {
            $data = array(
		'Tanggal' => $this->input->post('Tanggal',TRUE),
		'Pemasukan' => $this->input->post('Pemasukan',TRUE),
		'Pengeluaran' => $this->input->post('Pengeluaran',TRUE),
		'Setoran' => $this->input->post('Setoran',TRUE),
		'Laba_Kotor' => $this->input->post('Laba_Kotor',TRUE),
	    );

            $this->Income_model->update($this->input->post('nomor_income', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('income'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Income_model->get_by_id($id);

        if ($row) {
            $this->Income_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('income'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('income'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('Tanggal', 'tanggal', 'trim|required');
	$this->form_validation->set_rules('Pemasukan', 'pemasukan', 'trim|required');
	$this->form_validation->set_rules('Pengeluaran', 'pengeluaran', 'trim|required');
	$this->form_validation->set_rules('Setoran', 'setoran', 'trim|required');
	$this->form_validation->set_rules('Laba_Kotor', 'laba kotor', 'trim|required|numeric');

	$this->form_validation->set_rules('nomor_income', 'nomor_income', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

}

/* End of file Income.php */
/* Location: ./application/controllers/Income.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2020-10-16 21:24:25 */
/* http://harviacode.com */