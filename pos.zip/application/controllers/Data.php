<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Data extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Data_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $q = urldecode($this->input->get('q', TRUE));
        $start = intval($this->input->get('start'));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . 'data/index.html?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'data/index.html?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'data/index.html';
            $config['first_url'] = base_url() . 'data/index.html';
        }

        $config['per_page'] = 10;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->Data_model->total_rows($q);
        $data = $this->Data_model->get_limit_data($config['per_page'], $start, $q);

        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            'data_data' => $data,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
        );
        $this->load->view('data/data_list', $data);
    }

    public function read($id) 
    {
        $row = $this->Data_model->get_by_id($id);
        if ($row) {
            $data = array(
		'barang_kode' => $row->barang_kode,
		'Nama_Barang' => $row->Nama_Barang,
		'satuan' => $row->satuan,
		'produksi' => $row->produksi,
		'harga_modal' => $row->harga_modal,
		'harga_HET' => $row->harga_HET,
		'harga_jual' => $row->harga_jual,
		'harga_jamu' => $row->harga_jamu,
		'harga_grosir' => $row->harga_grosir,
		'stok_awal' => $row->stok_awal,
		'stok_akhir' => $row->stok_akhir,
		'tgl_stok_awal' => $row->tgl_stok_awal,
		'tgl_stok_akhir' => $row->tgl_stok_akhir,
	    );
            $this->load->view('data/data_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('data'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('data/create_action'),
	    'barang_kode' => set_value('barang_kode'),
	    'Nama_Barang' => set_value('Nama_Barang'),
	    'satuan' => set_value('satuan'),
	    'produksi' => set_value('produksi'),
	    'harga_modal' => set_value('harga_modal'),
	    'harga_HET' => set_value('harga_HET'),
	    'harga_jual' => set_value('harga_jual'),
	    'harga_jamu' => set_value('harga_jamu'),
	    'harga_grosir' => set_value('harga_grosir'),
	    'stok_awal' => set_value('stok_awal'),
	    'stok_akhir' => set_value('stok_akhir'),
	    'tgl_stok_awal' => set_value('tgl_stok_awal'),
	    'tgl_stok_akhir' => set_value('tgl_stok_akhir'),
	);
        $this->load->view('data/data_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'Nama_Barang' => $this->input->post('Nama_Barang',TRUE),
		'satuan' => $this->input->post('satuan',TRUE),
		'produksi' => $this->input->post('produksi',TRUE),
		'harga_modal' => $this->input->post('harga_modal',TRUE),
		'harga_HET' => $this->input->post('harga_HET',TRUE),
		'harga_jual' => $this->input->post('harga_jual',TRUE),
		'harga_jamu' => $this->input->post('harga_jamu',TRUE),
		'harga_grosir' => $this->input->post('harga_grosir',TRUE),
		'stok_awal' => $this->input->post('stok_awal',TRUE),
		'stok_akhir' => $this->input->post('stok_akhir',TRUE),
		'tgl_stok_awal' => $this->input->post('tgl_stok_awal',TRUE),
		'tgl_stok_akhir' => $this->input->post('tgl_stok_akhir',TRUE),
	    );

            $this->Data_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('data'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Data_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('data/update_action'),
		'barang_kode' => set_value('barang_kode', $row->barang_kode),
		'Nama_Barang' => set_value('Nama_Barang', $row->Nama_Barang),
		'satuan' => set_value('satuan', $row->satuan),
		'produksi' => set_value('produksi', $row->produksi),
		'harga_modal' => set_value('harga_modal', $row->harga_modal),
		'harga_HET' => set_value('harga_HET', $row->harga_HET),
		'harga_jual' => set_value('harga_jual', $row->harga_jual),
		'harga_jamu' => set_value('harga_jamu', $row->harga_jamu),
		'harga_grosir' => set_value('harga_grosir', $row->harga_grosir),
		'stok_awal' => set_value('stok_awal', $row->stok_awal),
		'stok_akhir' => set_value('stok_akhir', $row->stok_akhir),
		'tgl_stok_awal' => set_value('tgl_stok_awal', $row->tgl_stok_awal),
		'tgl_stok_akhir' => set_value('tgl_stok_akhir', $row->tgl_stok_akhir),
	    );
            $this->load->view('data/data_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('data'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('barang_kode', TRUE));
        } else {
            $data = array(
		'Nama_Barang' => $this->input->post('Nama_Barang',TRUE),
		'satuan' => $this->input->post('satuan',TRUE),
		'produksi' => $this->input->post('produksi',TRUE),
		'harga_modal' => $this->input->post('harga_modal',TRUE),
		'harga_HET' => $this->input->post('harga_HET',TRUE),
		'harga_jual' => $this->input->post('harga_jual',TRUE),
		'harga_jamu' => $this->input->post('harga_jamu',TRUE),
		'harga_grosir' => $this->input->post('harga_grosir',TRUE),
		'stok_awal' => $this->input->post('stok_awal',TRUE),
		'stok_akhir' => $this->input->post('stok_akhir',TRUE),
		'tgl_stok_awal' => $this->input->post('tgl_stok_awal',TRUE),
		'tgl_stok_akhir' => $this->input->post('tgl_stok_akhir',TRUE),
	    );

            $this->Data_model->update($this->input->post('barang_kode', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('data'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Data_model->get_by_id($id);

        if ($row) {
            $this->Data_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('data'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('data'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('Nama_Barang', 'nama barang', 'trim|required');
	$this->form_validation->set_rules('satuan', 'satuan', 'trim|required');
	$this->form_validation->set_rules('produksi', 'produksi', 'trim|required');
	$this->form_validation->set_rules('harga_modal', 'harga modal', 'trim|required');
	$this->form_validation->set_rules('harga_HET', 'harga het', 'trim|required');
	$this->form_validation->set_rules('harga_jual', 'harga jual', 'trim|required');
	$this->form_validation->set_rules('harga_jamu', 'harga jamu', 'trim|required');
	$this->form_validation->set_rules('harga_grosir', 'harga grosir', 'trim|required');
	$this->form_validation->set_rules('stok_awal', 'stok awal', 'trim|required');
	$this->form_validation->set_rules('stok_akhir', 'stok akhir', 'trim|required');
	$this->form_validation->set_rules('tgl_stok_awal', 'tgl stok awal', 'trim|required');
	$this->form_validation->set_rules('tgl_stok_akhir', 'tgl stok akhir', 'trim|required');

	$this->form_validation->set_rules('barang_kode', 'barang_kode', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

}

/* End of file Data.php */
/* Location: ./application/controllers/Data.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2020-10-16 21:24:25 */
/* http://harviacode.com */