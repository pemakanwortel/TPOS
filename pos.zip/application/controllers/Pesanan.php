<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Pesanan extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Pesanan_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $q = urldecode($this->input->get('q', TRUE));
        $start = intval($this->input->get('start'));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . 'pesanan/index.html?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'pesanan/index.html?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'pesanan/index.html';
            $config['first_url'] = base_url() . 'pesanan/index.html';
        }

        $config['per_page'] = 10;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->Pesanan_model->total_rows($q);
        $pesanan = $this->Pesanan_model->get_limit_data($config['per_page'], $start, $q);

        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            'pesanan_data' => $pesanan,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
        );
        $this->load->view('pesanan/pesanan_list', $data);
    }

    public function read($id) 
    {
        $row = $this->Pesanan_model->get_by_id($id);
        if ($row) {
            $data = array(
		'Nomor_Pesanan' => $row->Nomor_Pesanan,
		'Tanggal' => $row->Tanggal,
		'Nama_Pesanan' => $row->Nama_Pesanan,
		'Nama' => $row->Nama,
	    );
            $this->load->view('pesanan/pesanan_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('pesanan'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('pesanan/create_action'),
	    'Nomor_Pesanan' => set_value('Nomor_Pesanan'),
	    'Tanggal' => set_value('Tanggal'),
	    'Nama_Pesanan' => set_value('Nama_Pesanan'),
	    'Nama' => set_value('Nama'),
	);
        $this->load->view('pesanan/pesanan_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'Tanggal' => $this->input->post('Tanggal',TRUE),
		'Nama_Pesanan' => $this->input->post('Nama_Pesanan',TRUE),
		'Nama' => $this->input->post('Nama',TRUE),
	    );

            $this->Pesanan_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('pesanan'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Pesanan_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('pesanan/update_action'),
		'Nomor_Pesanan' => set_value('Nomor_Pesanan', $row->Nomor_Pesanan),
		'Tanggal' => set_value('Tanggal', $row->Tanggal),
		'Nama_Pesanan' => set_value('Nama_Pesanan', $row->Nama_Pesanan),
		'Nama' => set_value('Nama', $row->Nama),
	    );
            $this->load->view('pesanan/pesanan_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('pesanan'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('Nomor_Pesanan', TRUE));
        } else {
            $data = array(
		'Tanggal' => $this->input->post('Tanggal',TRUE),
		'Nama_Pesanan' => $this->input->post('Nama_Pesanan',TRUE),
		'Nama' => $this->input->post('Nama',TRUE),
	    );

            $this->Pesanan_model->update($this->input->post('Nomor_Pesanan', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('pesanan'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Pesanan_model->get_by_id($id);

        if ($row) {
            $this->Pesanan_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('pesanan'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('pesanan'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('Tanggal', 'tanggal', 'trim|required');
	$this->form_validation->set_rules('Nama_Pesanan', 'nama pesanan', 'trim|required');
	$this->form_validation->set_rules('Nama', 'nama', 'trim|required');

	$this->form_validation->set_rules('Nomor_Pesanan', 'Nomor_Pesanan', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

}

/* End of file Pesanan.php */
/* Location: ./application/controllers/Pesanan.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2020-10-16 21:24:25 */
/* http://harviacode.com */