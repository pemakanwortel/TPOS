<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Kategori extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Kategori_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $q = urldecode($this->input->get('q', TRUE));
        $start = intval($this->input->get('start'));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . 'kategori/index.html?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'kategori/index.html?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'kategori/index.html';
            $config['first_url'] = base_url() . 'kategori/index.html';
        }

        $config['per_page'] = 10;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->Kategori_model->total_rows($q);
        $kategori = $this->Kategori_model->get_limit_data($config['per_page'], $start, $q);

        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            'kategori_data' => $kategori,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
        );
        $this->load->view('kategori/kategori_list', $data);
    }

    public function read($id) 
    {
        $row = $this->Kategori_model->get_by_id($id);
        if ($row) {
            $data = array(
		'Herbal' => $row->Herbal,
		'Madu' => $row->Madu,
		'Jamu' => $row->Jamu,
		'Racikan' => $row->Racikan,
		'Salep' => $row->Salep,
		'Cair' => $row->Cair,
		'Padat' => $row->Padat,
		'Sabun' => $row->Sabun,
	    );
            $this->load->view('kategori/kategori_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('kategori'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('kategori/create_action'),
	    'Herbal' => set_value('Herbal'),
	    'Madu' => set_value('Madu'),
	    'Jamu' => set_value('Jamu'),
	    'Racikan' => set_value('Racikan'),
	    'Salep' => set_value('Salep'),
	    'Cair' => set_value('Cair'),
	    'Padat' => set_value('Padat'),
	    'Sabun' => set_value('Sabun'),
	);
        $this->load->view('kategori/kategori_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'Herbal' => $this->input->post('Herbal',TRUE),
		'Madu' => $this->input->post('Madu',TRUE),
		'Jamu' => $this->input->post('Jamu',TRUE),
		'Racikan' => $this->input->post('Racikan',TRUE),
		'Salep' => $this->input->post('Salep',TRUE),
		'Cair' => $this->input->post('Cair',TRUE),
		'Padat' => $this->input->post('Padat',TRUE),
		'Sabun' => $this->input->post('Sabun',TRUE),
	    );

            $this->Kategori_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success');
            redirect(site_url('kategori'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Kategori_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('kategori/update_action'),
		'Herbal' => set_value('Herbal', $row->Herbal),
		'Madu' => set_value('Madu', $row->Madu),
		'Jamu' => set_value('Jamu', $row->Jamu),
		'Racikan' => set_value('Racikan', $row->Racikan),
		'Salep' => set_value('Salep', $row->Salep),
		'Cair' => set_value('Cair', $row->Cair),
		'Padat' => set_value('Padat', $row->Padat),
		'Sabun' => set_value('Sabun', $row->Sabun),
	    );
            $this->load->view('kategori/kategori_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('kategori'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('', TRUE));
        } else {
            $data = array(
		'Herbal' => $this->input->post('Herbal',TRUE),
		'Madu' => $this->input->post('Madu',TRUE),
		'Jamu' => $this->input->post('Jamu',TRUE),
		'Racikan' => $this->input->post('Racikan',TRUE),
		'Salep' => $this->input->post('Salep',TRUE),
		'Cair' => $this->input->post('Cair',TRUE),
		'Padat' => $this->input->post('Padat',TRUE),
		'Sabun' => $this->input->post('Sabun',TRUE),
	    );

            $this->Kategori_model->update($this->input->post('', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('kategori'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Kategori_model->get_by_id($id);

        if ($row) {
            $this->Kategori_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('kategori'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('kategori'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('Herbal', 'herbal', 'trim|required');
	$this->form_validation->set_rules('Madu', 'madu', 'trim|required');
	$this->form_validation->set_rules('Jamu', 'jamu', 'trim|required');
	$this->form_validation->set_rules('Racikan', 'racikan', 'trim|required');
	$this->form_validation->set_rules('Salep', 'salep', 'trim|required');
	$this->form_validation->set_rules('Cair', 'cair', 'trim|required');
	$this->form_validation->set_rules('Padat', 'padat', 'trim|required');
	$this->form_validation->set_rules('Sabun', 'sabun', 'trim|required');

	$this->form_validation->set_rules('', '', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

}

/* End of file Kategori.php */
/* Location: ./application/controllers/Kategori.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2020-10-16 21:24:25 */
/* http://harviacode.com */