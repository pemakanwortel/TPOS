<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Kategori <?php echo $button ?></h2>
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="char">Herbal <?php echo form_error('Herbal') ?></label>
            <input type="text" class="form-control" name="Herbal" id="Herbal" placeholder="Herbal" value="<?php echo $Herbal; ?>" />
        </div>
	    <div class="form-group">
            <label for="char">Madu <?php echo form_error('Madu') ?></label>
            <input type="text" class="form-control" name="Madu" id="Madu" placeholder="Madu" value="<?php echo $Madu; ?>" />
        </div>
	    <div class="form-group">
            <label for="char">Jamu <?php echo form_error('Jamu') ?></label>
            <input type="text" class="form-control" name="Jamu" id="Jamu" placeholder="Jamu" value="<?php echo $Jamu; ?>" />
        </div>
	    <div class="form-group">
            <label for="char">Racikan <?php echo form_error('Racikan') ?></label>
            <input type="text" class="form-control" name="Racikan" id="Racikan" placeholder="Racikan" value="<?php echo $Racikan; ?>" />
        </div>
	    <div class="form-group">
            <label for="char">Salep <?php echo form_error('Salep') ?></label>
            <input type="text" class="form-control" name="Salep" id="Salep" placeholder="Salep" value="<?php echo $Salep; ?>" />
        </div>
	    <div class="form-group">
            <label for="char">Cair <?php echo form_error('Cair') ?></label>
            <input type="text" class="form-control" name="Cair" id="Cair" placeholder="Cair" value="<?php echo $Cair; ?>" />
        </div>
	    <div class="form-group">
            <label for="char">Padat <?php echo form_error('Padat') ?></label>
            <input type="text" class="form-control" name="Padat" id="Padat" placeholder="Padat" value="<?php echo $Padat; ?>" />
        </div>
	    <div class="form-group">
            <label for="char">Sabun <?php echo form_error('Sabun') ?></label>
            <input type="text" class="form-control" name="Sabun" id="Sabun" placeholder="Sabun" value="<?php echo $Sabun; ?>" />
        </div>
	    <input type="hidden" name="" value="<?php echo $; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('kategori') ?>" class="btn btn-default">Cancel</a>
	</form>
    </body>
</html>