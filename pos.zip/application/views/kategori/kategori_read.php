<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Kategori Read</h2>
        <table class="table">
	    <tr><td>Herbal</td><td><?php echo $Herbal; ?></td></tr>
	    <tr><td>Madu</td><td><?php echo $Madu; ?></td></tr>
	    <tr><td>Jamu</td><td><?php echo $Jamu; ?></td></tr>
	    <tr><td>Racikan</td><td><?php echo $Racikan; ?></td></tr>
	    <tr><td>Salep</td><td><?php echo $Salep; ?></td></tr>
	    <tr><td>Cair</td><td><?php echo $Cair; ?></td></tr>
	    <tr><td>Padat</td><td><?php echo $Padat; ?></td></tr>
	    <tr><td>Sabun</td><td><?php echo $Sabun; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('kategori') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
</html>