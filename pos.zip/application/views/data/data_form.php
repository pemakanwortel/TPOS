<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Data <?php echo $button ?></h2>
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="char">Nama Barang <?php echo form_error('Nama_Barang') ?></label>
            <input type="text" class="form-control" name="Nama_Barang" id="Nama_Barang" placeholder="Nama Barang" value="<?php echo $Nama_Barang; ?>" />
        </div>
	    <div class="form-group">
            <label for="char">Satuan <?php echo form_error('satuan') ?></label>
            <input type="text" class="form-control" name="satuan" id="satuan" placeholder="Satuan" value="<?php echo $satuan; ?>" />
        </div>
	    <div class="form-group">
            <label for="char">Produksi <?php echo form_error('produksi') ?></label>
            <input type="text" class="form-control" name="produksi" id="produksi" placeholder="Produksi" value="<?php echo $produksi; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Harga Modal <?php echo form_error('harga_modal') ?></label>
            <input type="text" class="form-control" name="harga_modal" id="harga_modal" placeholder="Harga Modal" value="<?php echo $harga_modal; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Harga HET <?php echo form_error('harga_HET') ?></label>
            <input type="text" class="form-control" name="harga_HET" id="harga_HET" placeholder="Harga HET" value="<?php echo $harga_HET; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Harga Jual <?php echo form_error('harga_jual') ?></label>
            <input type="text" class="form-control" name="harga_jual" id="harga_jual" placeholder="Harga Jual" value="<?php echo $harga_jual; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Harga Jamu <?php echo form_error('harga_jamu') ?></label>
            <input type="text" class="form-control" name="harga_jamu" id="harga_jamu" placeholder="Harga Jamu" value="<?php echo $harga_jamu; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Harga Grosir <?php echo form_error('harga_grosir') ?></label>
            <input type="text" class="form-control" name="harga_grosir" id="harga_grosir" placeholder="Harga Grosir" value="<?php echo $harga_grosir; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Stok Awal <?php echo form_error('stok_awal') ?></label>
            <input type="text" class="form-control" name="stok_awal" id="stok_awal" placeholder="Stok Awal" value="<?php echo $stok_awal; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Stok Akhir <?php echo form_error('stok_akhir') ?></label>
            <input type="text" class="form-control" name="stok_akhir" id="stok_akhir" placeholder="Stok Akhir" value="<?php echo $stok_akhir; ?>" />
        </div>
	    <div class="form-group">
            <label for="date">Tgl Stok Awal <?php echo form_error('tgl_stok_awal') ?></label>
            <input type="text" class="form-control" name="tgl_stok_awal" id="tgl_stok_awal" placeholder="Tgl Stok Awal" value="<?php echo $tgl_stok_awal; ?>" />
        </div>
	    <div class="form-group">
            <label for="date">Tgl Stok Akhir <?php echo form_error('tgl_stok_akhir') ?></label>
            <input type="text" class="form-control" name="tgl_stok_akhir" id="tgl_stok_akhir" placeholder="Tgl Stok Akhir" value="<?php echo $tgl_stok_akhir; ?>" />
        </div>
	    <input type="hidden" name="barang_kode" value="<?php echo $barang_kode; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('data') ?>" class="btn btn-default">Cancel</a>
	</form>
    </body>
</html>