<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Income <?php echo $button ?></h2>
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="date">Tanggal <?php echo form_error('Tanggal') ?></label>
            <input type="text" class="form-control" name="Tanggal" id="Tanggal" placeholder="Tanggal" value="<?php echo $Tanggal; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Pemasukan <?php echo form_error('Pemasukan') ?></label>
            <input type="text" class="form-control" name="Pemasukan" id="Pemasukan" placeholder="Pemasukan" value="<?php echo $Pemasukan; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Pengeluaran <?php echo form_error('Pengeluaran') ?></label>
            <input type="text" class="form-control" name="Pengeluaran" id="Pengeluaran" placeholder="Pengeluaran" value="<?php echo $Pengeluaran; ?>" />
        </div>
	    <div class="form-group">
            <label for="int">Setoran <?php echo form_error('Setoran') ?></label>
            <input type="text" class="form-control" name="Setoran" id="Setoran" placeholder="Setoran" value="<?php echo $Setoran; ?>" />
        </div>
	    <div class="form-group">
            <label for="double">Laba Kotor <?php echo form_error('Laba_Kotor') ?></label>
            <input type="text" class="form-control" name="Laba_Kotor" id="Laba_Kotor" placeholder="Laba Kotor" value="<?php echo $Laba_Kotor; ?>" />
        </div>
	    <input type="hidden" name="nomor_income" value="<?php echo $nomor_income; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('income') ?>" class="btn btn-default">Cancel</a>
	</form>
    </body>
</html>