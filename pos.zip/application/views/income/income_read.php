<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Income Read</h2>
        <table class="table">
	    <tr><td>Tanggal</td><td><?php echo $Tanggal; ?></td></tr>
	    <tr><td>Pemasukan</td><td><?php echo $Pemasukan; ?></td></tr>
	    <tr><td>Pengeluaran</td><td><?php echo $Pengeluaran; ?></td></tr>
	    <tr><td>Setoran</td><td><?php echo $Setoran; ?></td></tr>
	    <tr><td>Laba Kotor</td><td><?php echo $Laba_Kotor; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('income') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
</html>